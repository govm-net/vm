// Package main provides a command-line tool for working with WASI contracts
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"

	"github.com/govm-net/vm/core"
	"github.com/govm-net/vm/vm"
	"github.com/govm-net/vm/vm/api"
	"github.com/govm-net/vm/vm/wasi"
)

var (
	// Global flags
	wasiDir    = flag.String("wasi-dir", "./wasi", "Directory for WASI contracts and storage")
	tinyGoPath = flag.String("tinygo", "tinygo", "Path to TinyGo executable")
	verbose    = flag.Bool("verbose", false, "Enable verbose output")

	// Command-specific flags
	sourceFile   = flag.String("source", "", "Source file for the contract")
	contractAddr = flag.String("contract", "", "Contract address")
	function     = flag.String("function", "", "Function to call")
	argsJSON     = flag.String("args", "[]", "Function arguments as JSON array")
)

func main() {
	flag.Parse()

	// Get the command
	args := flag.Args()
	if len(args) < 1 {
		printUsage()
		os.Exit(1)
	}

	command := args[0]

	// Create WASI integration
	if err := os.MkdirAll(*wasiDir, 0755); err != nil {
		fmt.Printf("Error: Failed to create WASI directory: %v\n", err)
		os.Exit(1)
	}

	// Execute the command
	switch command {
	case "compile":
		compileContract()
	case "deploy":
		deployContract()
	case "execute":
		executeContract()
	case "help":
		printUsage()
	default:
		fmt.Printf("Error: Unknown command '%s'\n", command)
		printUsage()
		os.Exit(1)
	}
}

func printUsage() {
	fmt.Println("WASI Contract Tool")
	fmt.Println("Commands:")
	fmt.Println("  compile   Compile a Go contract to WebAssembly")
	fmt.Println("  deploy    Deploy a Go contract")
	fmt.Println("  execute   Execute a function on a deployed contract")
	fmt.Println("  help      Show this help message")
	fmt.Println("\nGlobal Flags:")
	fmt.Println("  --wasi-dir=DIR    Directory for WASI contracts and storage (default: ./wasi)")
	fmt.Println("  --tinygo=PATH     Path to TinyGo executable (default: tinygo)")
	fmt.Println("  --verbose         Enable verbose output")
	fmt.Println("\nCompile Flags:")
	fmt.Println("  --source=FILE     Source file for the contract (required)")
	fmt.Println("\nDeploy Flags:")
	fmt.Println("  --source=FILE     Source file for the contract (required)")
	fmt.Println("\nExecute Flags:")
	fmt.Println("  --contract=ADDR   Contract address (required)")
	fmt.Println("  --function=NAME   Function to call (required)")
	fmt.Println("  --args=JSON       Function arguments as JSON array (default: [])")
}

func compileContract() {
	if *sourceFile == "" {
		fmt.Println("Error: Source file is required")
		os.Exit(1)
	}

	// Read the source file
	source, err := ioutil.ReadFile(*sourceFile)
	if err != nil {
		fmt.Printf("Error: Failed to read source file: %v\n", err)
		os.Exit(1)
	}

	// Create a compiler
	compiler := wasi.NewWASICompiler(*tinyGoPath, *wasiDir)

	// Compile the contract
	wasmBytes, err := compiler.CompileContract(source)
	if err != nil {
		fmt.Printf("Error: Failed to compile contract: %v\n", err)
		os.Exit(1)
	}

	// Write the compiled contract to a file
	outputFile := filepath.Base(*sourceFile)
	outputFile = outputFile[:len(outputFile)-3] + ".wasm" // Replace .go with .wasm

	if err := ioutil.WriteFile(outputFile, wasmBytes, 0644); err != nil {
		fmt.Printf("Error: Failed to write compiled contract: %v\n", err)
		os.Exit(1)
	}

	fmt.Printf("Contract compiled successfully to %s\n", outputFile)
}

func deployContract() {
	if *sourceFile == "" {
		fmt.Println("Error: Source file is required")
		os.Exit(1)
	}

	// Read the source file
	source, err := ioutil.ReadFile(*sourceFile)
	if err != nil {
		fmt.Printf("Error: Failed to read source file: %v\n", err)
		os.Exit(1)
	}

	// Create engine with WASI support
	engine, err := vm.NewEngineWithOptions(vm.EngineOptions{
		ContractConfig: api.ContractConfig{
			MaxCodeSize: 1024 * 1024, // 1MB
		},
		EnableWASI: true,
		WASIDir:    *wasiDir,
		TinyGoPath: *tinyGoPath,
	})
	if err != nil {
		fmt.Printf("Error: Failed to create VM engine: %v\n", err)
		os.Exit(1)
	}

	// Deploy the contract
	address, err := engine.Deploy(source)
	if err != nil {
		fmt.Printf("Error: Failed to deploy contract: %v\n", err)
		os.Exit(1)
	}

	fmt.Printf("Contract deployed successfully\n")
	fmt.Printf("Contract address: %s\n", address.String())
}

func executeContract() {
	if *contractAddr == "" {
		fmt.Println("Error: Contract address is required")
		os.Exit(1)
	}

	if *function == "" {
		fmt.Println("Error: Function name is required")
		os.Exit(1)
	}

	// Parse the contract address
	var address core.Address
	addrBytes, err := wasi.AddressFromHexString(*contractAddr)
	if err != nil {
		fmt.Printf("Error: Invalid contract address: %v\n", err)
		os.Exit(1)
	}
	address = addrBytes

	// Parse the arguments
	var args []interface{}
	if err := json.Unmarshal([]byte(*argsJSON), &args); err != nil {
		fmt.Printf("Error: Invalid arguments JSON: %v\n", err)
		os.Exit(1)
	}

	// Convert args to []byte
	byteArgs := make([][]byte, len(args))
	for i, arg := range args {
		argBytes, err := json.Marshal(arg)
		if err != nil {
			fmt.Printf("Error: Failed to encode argument %d: %v\n", i, err)
			os.Exit(1)
		}
		byteArgs[i] = argBytes
	}

	// Create engine with WASI support
	engine, err := vm.NewEngineWithOptions(vm.EngineOptions{
		ContractConfig: api.ContractConfig{
			MaxCodeSize: 1024 * 1024, // 1MB
		},
		EnableWASI: true,
		WASIDir:    *wasiDir,
		TinyGoPath: *tinyGoPath,
	})
	if err != nil {
		fmt.Printf("Error: Failed to create VM engine: %v\n", err)
		os.Exit(1)
	}

	// Execute the function
	result, err := engine.Execute(address, *function, byteArgs...)
	if err != nil {
		fmt.Printf("Error: Function execution failed: %v\n", err)
		os.Exit(1)
	}

	// Format and print the result
	if result == nil {
		fmt.Println("Result: <nil>")
	} else {
		var prettyResult interface{}
		if err := json.Unmarshal(result, &prettyResult); err != nil {
			// If not JSON, print raw bytes
			fmt.Printf("Result: %s\n", string(result))
		} else {
			// Pretty-print JSON
			prettyJSON, err := json.MarshalIndent(prettyResult, "", "  ")
			if err != nil {
				fmt.Printf("Result: %s\n", string(result))
			} else {
				fmt.Printf("Result: \n%s\n", string(prettyJSON))
			}
		}
	}
}

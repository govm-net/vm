package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/govm-net/vm/vm/wasi"
	"github.com/urfave/cli/v2"
)

// generateABI 从WASM文件生成ABI并保存到JSON和接口定义文件
func generateABI(inputFile, outputFile, contractName string) error {
	// 检查输入文件是否存在
	if _, err := os.Stat(inputFile); os.IsNotExist(err) {
		return fmt.Errorf("input file does not exist: %s", inputFile)
	}

	// 如果没有指定输出文件，则根据输入文件名生成
	if outputFile == "" {
		baseName := filepath.Base(inputFile)
		ext := filepath.Ext(baseName)
		baseName = strings.TrimSuffix(baseName, ext)
		outputFile = baseName + ".abi.json"
	}

	// 如果没有指定合约名称，则使用文件名
	if contractName == "" {
		baseName := filepath.Base(inputFile)
		ext := filepath.Ext(baseName)
		contractName = strings.TrimSuffix(baseName, ext)
	}

	// 读取WASM文件
	wasmBytes, err := os.ReadFile(inputFile)
	if err != nil {
		return fmt.Errorf("failed to read WASM file: %w", err)
	}

	// 提取ABI
	abi, err := wasi.ExtractABI(wasmBytes)
	if err != nil {
		return fmt.Errorf("failed to extract ABI: %w", err)
	}

	// 生成ABI JSON
	abiJSON, err := abi.GenerateABIJSON()
	if err != nil {
		return fmt.Errorf("failed to generate ABI JSON: %w", err)
	}

	// 保存ABI JSON
	err = os.WriteFile(outputFile, []byte(abiJSON), 0644)
	if err != nil {
		return fmt.Errorf("failed to write ABI JSON file: %w", err)
	}

	// 生成并保存接口定义
	interfaceFile := strings.TrimSuffix(outputFile, ".json") + ".interface.txt"
	interfaceDef := abi.GenerateInterfaceDefinition(contractName)
	err = os.WriteFile(interfaceFile, []byte(interfaceDef), 0644)
	if err != nil {
		return fmt.Errorf("failed to write interface definition file: %w", err)
	}

	fmt.Printf("Generated ABI: %s\n", outputFile)
	fmt.Printf("Generated interface definition: %s\n", interfaceFile)
	return nil
}

// setupABICommand 设置ABI生成命令
func setupABICommand() *cli.Command {
	return &cli.Command{
		Name:    "abi",
		Aliases: []string{"extract-abi"},
		Usage:   "Extract ABI from a WASM file",
		Flags: []cli.Flag{
			&cli.StringFlag{
				Name:     "input",
				Aliases:  []string{"i"},
				Usage:    "Input WASM file",
				Required: true,
			},
			&cli.StringFlag{
				Name:    "output",
				Aliases: []string{"o"},
				Usage:   "Output ABI JSON file",
			},
			&cli.StringFlag{
				Name:    "name",
				Aliases: []string{"n"},
				Usage:   "Contract name for interface generation",
			},
		},
		Action: func(c *cli.Context) error {
			return generateABI(c.String("input"), c.String("output"), c.String("name"))
		},
	}
}

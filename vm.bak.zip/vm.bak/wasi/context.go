// Package wasi implements WebAssembly System Interface for smart contracts
package wasi

import (
	"github.com/govm-net/vm/core"
)

// WASIContext 是对 core.Context 的扩展，提供 WASI 合约所需的额外功能
type WASIContext interface {
	core.Context

	// 状态存储和检索方法
	GetState(contractAddress string, key string) ([]byte, error)
	SetState(contractAddress string, key string, value []byte) error

	// 合约代码存储和检索
	StoreContractCode(contractAddress string, code []byte) error
	LoadContractCode(contractAddress string) ([]byte, error)

	// 合约存在性检查
	ContractExists(contractAddress string) bool

	// 验证合约类型
	IsWASIContract(contractAddress string) (bool, error)
}

// ContextAdapter 将 core.Context 适配为 WASIContext
type ContextAdapter struct {
	core.Context                               // 嵌入原始 Context
	contractStore map[string][]byte            // 合约代码存储
	stateStore    map[string]map[string][]byte // 合约状态存储
}

// NewContextAdapter 创建一个新的 Context 适配器
func NewContextAdapter(ctx core.Context) *ContextAdapter {
	return &ContextAdapter{
		Context:       ctx,
		contractStore: make(map[string][]byte),
		stateStore:    make(map[string]map[string][]byte),
	}
}

// GetState 获取合约状态
func (c *ContextAdapter) GetState(contractAddress string, key string) ([]byte, error) {
	contractState, exists := c.stateStore[contractAddress]
	if !exists {
		return nil, nil // 合约不存在，返回空
	}

	value, exists := contractState[key]
	if !exists {
		return nil, nil // 键不存在，返回空
	}

	return value, nil
}

// SetState 设置合约状态
func (c *ContextAdapter) SetState(contractAddress string, key string, value []byte) error {
	// 确保合约状态存储已初始化
	if _, exists := c.stateStore[contractAddress]; !exists {
		c.stateStore[contractAddress] = make(map[string][]byte)
	}

	// 设置状态
	c.stateStore[contractAddress][key] = value
	return nil
}

// StoreContractCode 存储合约代码
func (c *ContextAdapter) StoreContractCode(contractAddress string, code []byte) error {
	c.contractStore[contractAddress] = code
	return nil
}

// LoadContractCode 加载合约代码
func (c *ContextAdapter) LoadContractCode(contractAddress string) ([]byte, error) {
	code, exists := c.contractStore[contractAddress]
	if !exists {
		return nil, nil // 合约不存在，返回空
	}

	return code, nil
}

// ContractExists 检查合约是否存在
func (c *ContextAdapter) ContractExists(contractAddress string) bool {
	_, exists := c.contractStore[contractAddress]
	return exists
}

// IsWASIContract 检查合约是否是 WASI 合约
func (c *ContextAdapter) IsWASIContract(contractAddress string) (bool, error) {
	code, exists := c.contractStore[contractAddress]
	if !exists {
		return false, nil
	}

	// 验证 WebAssembly 魔数
	if len(code) < 8 {
		return false, nil
	}

	isWasm := code[0] == 0x00 && code[1] == 0x61 && code[2] == 0x73 && code[3] == 0x6d
	return isWasm, nil
}

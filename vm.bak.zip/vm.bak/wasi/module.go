// Package wasi provides WebAssembly System Interface implementation
// for the VM to execute smart contracts compiled to WebAssembly.
package wasi

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"github.com/wasmerio/wasmer-go/wasmer"
)

// WASIError represents an error from WASI operations
type WASIError struct {
	Message string
	Cause   error
}

func (e *WASIError) Error() string {
	if e.Cause != nil {
		return fmt.Sprintf("%s: %s", e.Message, e.Cause.Error())
	}
	return e.Message
}

func (e *WASIError) Unwrap() error {
	return e.Cause
}

// WASIOptions defines the configuration options for WASI contract execution
type WASIOptions struct {
	MemoryLimit      uint32            // Memory limit in bytes
	Timeout          uint32            // Execution timeout in milliseconds
	FuelLimit        uint64            // Instruction count limit
	StackSize        uint32            // Stack size in bytes
	PrecompiledCache bool              // Whether to use precompiled cache
	CacheDir         string            // Directory for precompiled cache
	LogLevel         string            // Log level (trace, debug, info, warn, error)
	Env              map[string]string // Environment variables
	EnableFileSystem bool              // Whether to enable file system
	MaxMemoryMB      uint32            // Maximum memory in MB
	Args             []string          // Command-line arguments
	Dirs             map[string]string // Directory mapping (host path => WASI path)
	TimeoutMS        int64             // Execution timeout in milliseconds
}

// DefaultWASIOptions returns the default options for WASI execution
func DefaultWASIOptions() WASIOptions {
	return WASIOptions{
		MemoryLimit:      64 * 1024 * 1024, // 64MB
		Timeout:          5000,             // 5 seconds
		FuelLimit:        10_000_000,       // 10M instructions
		StackSize:        64 * 1024,        // 64KB
		PrecompiledCache: true,
		CacheDir:         "./wasm_cache",
		LogLevel:         "info",
		EnableFileSystem: false,
		MaxMemoryMB:      32,
		Env:              map[string]string{},
		Args:             []string{},
		Dirs:             map[string]string{},
		TimeoutMS:        5000,
	}
}

// Logger interface for WASI logging
type Logger interface {
	Log(message string, args ...any)
}

// WasmInstance represents a loaded WebAssembly module instance
type WasmInstance struct {
	// WebAssembly Components (Wasmer)
	instance *wasmer.Instance
	memory   *wasmer.Memory
	exports  map[string]interface{}
	store    *wasmer.Store
	engine   *wasmer.Engine

	// Logger for output
	logger Logger

	// Synchronization
	mutex sync.Mutex
}

// NewWasmInstance creates a new WebAssembly instance from the given module
func NewWasmInstance(wasmBytes []byte, logger Logger, options WASIOptions) (*WasmInstance, error) {
	// Create engine and store
	engine := wasmer.NewEngine()
	store := wasmer.NewStore(engine)

	// Compile module
	module, err := wasmer.NewModule(store, wasmBytes)
	if err != nil {
		return nil, &WASIError{Message: "failed to compile WebAssembly module", Cause: err}
	}

	// Create empty import object
	importObject := wasmer.NewImportObject()

	// Instantiate module
	instance, err := wasmer.NewInstance(module, importObject)
	if err != nil {
		return nil, &WASIError{Message: "failed to instantiate WebAssembly module", Cause: err}
	}

	// Get memory
	memory, err := instance.Exports.GetMemory("memory")
	if err != nil {
		return nil, &WASIError{Message: "WebAssembly module has no memory export", Cause: err}
	}

	// Create exports map
	exports := make(map[string]interface{})

	return &WasmInstance{
		instance: instance,
		memory:   memory,
		exports:  exports,
		store:    store,
		engine:   engine,
		logger:   logger,
	}, nil
}

// Close releases resources used by the instance
func (w *WasmInstance) Close() error {
	// Release Wasmer resources
	if w.instance != nil {
		w.instance = nil
	}
	w.memory = nil
	w.exports = nil
	w.store = nil
	w.engine = nil

	return nil
}

// Call invokes a function in the WebAssembly module
func (w *WasmInstance) Call(functionName string, args ...interface{}) (interface{}, error) {
	w.mutex.Lock()
	defer w.mutex.Unlock()

	// 查找导出函数
	exportObj, exists := w.exports[functionName]
	if !exists {
		// 尝试从实例获取函数
		exportedFunc, err := w.instance.Exports.GetFunction(functionName)
		if err != nil {
			return nil, &WASIError{
				Message: fmt.Sprintf("function %s not found in WebAssembly module", functionName),
				Cause:   err,
			}
		}
		w.exports[functionName] = exportedFunc
		exportObj = exportedFunc
	}

	// 获取函数
	wasmFunc, ok := exportObj.(func(...interface{}) (interface{}, error))
	if !ok {
		return nil, &WASIError{
			Message: fmt.Sprintf("export %s is not a function", functionName),
		}
	}

	// 转换参数
	callArgs := make([]interface{}, len(args))
	for i, arg := range args {
		// 根据参数类型进行转换
		switch v := arg.(type) {
		case int:
			callArgs[i] = int32(v)
		case int32, int64, uint32, uint64, float32, float64, bool:
			callArgs[i] = v
		case string:
			// 将字符串写入到内存并传递内存指针
			ptr, err := w.writeStringToMemory(v)
			if err != nil {
				return nil, &WASIError{
					Message: fmt.Sprintf("failed to write string argument to memory"),
					Cause:   err,
				}
			}
			callArgs[i] = int32(ptr)
		case []byte:
			// 将字节数组写入到内存并传递内存指针
			ptr, err := w.writeBytesToMemory(v)
			if err != nil {
				return nil, &WASIError{
					Message: fmt.Sprintf("failed to write bytes argument to memory"),
					Cause:   err,
				}
			}
			callArgs[i] = int32(ptr)
		default:
			return nil, &WASIError{
				Message: fmt.Sprintf("unsupported argument type for position %d: %T", i, arg),
			}
		}
	}

	// 调用函数
	w.logger.Log("Calling WebAssembly function: %s", functionName)
	result, err := wasmFunc(callArgs...)
	if err != nil {
		return nil, &WASIError{
			Message: fmt.Sprintf("error calling function %s", functionName),
			Cause:   err,
		}
	}

	return result, nil
}

// writeStringToMemory writes a string to WebAssembly memory and returns the pointer
func (w *WasmInstance) writeStringToMemory(s string) (uint32, error) {
	bytes := []byte(s)

	// 分配内存
	ptr, err := w.AllocateMemory(uint32(len(bytes)))
	if err != nil {
		return 0, err
	}

	// 写入内存
	if err := w.WriteMemory(ptr, bytes); err != nil {
		return 0, err
	}

	return ptr, nil
}

// writeBytesToMemory writes a byte array to WebAssembly memory and returns the pointer
func (w *WasmInstance) writeBytesToMemory(data []byte) (uint32, error) {
	// 分配内存
	ptr, err := w.AllocateMemory(uint32(len(data)))
	if err != nil {
		return 0, err
	}

	// 写入内存
	if err := w.WriteMemory(ptr, data); err != nil {
		return 0, err
	}

	return ptr, nil
}

// convertWasmValueToGo converts a Wasmer value to a Go value
func (w *WasmInstance) convertWasmValueToGo(value wasmer.Value) (interface{}, error) {
	kind := value.Kind()

	switch kind {
	case wasmer.I32:
		return value.I32(), nil
	case wasmer.I64:
		return value.I64(), nil
	case wasmer.F32:
		return value.F32(), nil
	case wasmer.F64:
		return value.F64(), nil
	default:
		return nil, fmt.Errorf("unsupported WebAssembly value kind: %v", kind)
	}
}

// ReadMemory reads from the WebAssembly module's memory
func (w *WasmInstance) ReadMemory(offset uint32, size uint32) ([]byte, error) {
	if w.memory == nil {
		return nil, errors.New("no memory available")
	}

	// Check bounds
	if uint64(offset)+uint64(size) > uint64(w.memory.Size()) {
		return nil, errors.New("memory access out of bounds")
	}

	// Get memory data and copy it
	data := make([]byte, size)
	copy(data, w.memory.Data()[offset:offset+size])
	return data, nil
}

// WriteMemory writes to the WebAssembly module's memory
func (w *WasmInstance) WriteMemory(offset uint32, data []byte) error {
	if w.memory == nil {
		return errors.New("no memory available")
	}

	// Check bounds
	if uint64(offset)+uint64(len(data)) > uint64(w.memory.Size()) {
		return errors.New("memory access out of bounds")
	}

	// Copy data to memory
	copy(w.memory.Data()[offset:], data)
	return nil
}

// AllocateMemory allocates memory in the WebAssembly module
func (w *WasmInstance) AllocateMemory(size uint32) (uint32, error) {
	// 检查是否有内存导出
	if w.memory == nil {
		return 0, errors.New("no memory available")
	}

	// 查找vm_alloc函数（应由WASI合约导出）
	allocFunc, err := w.instance.Exports.GetFunction("vm_alloc")
	if err != nil {
		// 尝试查找其他常见的内存分配函数名
		allocFunc, err = w.instance.Exports.GetFunction("malloc")
		if err != nil {
			// 如果没有导出内存分配函数，实现一个简单的内存分配策略
			// 注意：这只是一个示例，实际生产环境中应该有更健壮的实现
			// 分配固定大小的内存块（这里简化处理，实际应该有更复杂的内存管理）

			// 计算内存大小（字节为单位）
			memorySizeBytes := uint64(len(w.memory.Data()))

			// 确保有足够的内存可用
			if uint64(size) > memorySizeBytes {
				return 0, errors.New("not enough memory available")
			}

			// 返回一个简单的地址（实际应该管理内存分配表）
			// 这里返回内存的开始位置+1024，以避免与低地址区域冲突
			return 1024, nil
		}
	}

	// 调用WebAssembly模块的内存分配函数
	result, err := allocFunc(int32(size))
	if err != nil {
		return 0, err
	}

	// 转换结果为uint32指针
	ptr, ok := result.(int32)
	if !ok {
		return 0, errors.New("unexpected return type from memory allocation function")
	}

	// 检查指针是否有效
	if ptr <= 0 {
		return 0, errors.New("memory allocation failed")
	}

	return uint32(ptr), nil
}

// FreeMemory frees memory in the WebAssembly module
func (w *WasmInstance) FreeMemory(pointer uint32) error {
	// 查找vm_free函数（应由WASI合约导出）
	freeFunc, err := w.instance.Exports.GetFunction("vm_free")
	if err != nil {
		// 尝试查找其他常见的内存释放函数名
		freeFunc, err = w.instance.Exports.GetFunction("free")
		if err != nil {
			// 如果没有导出内存释放函数，简单地返回成功
			// 注意：这只是一个示例，实际生产环境中应该有更健壮的实现
			return nil
		}
	}

	// 调用WebAssembly模块的内存释放函数
	_, err = freeFunc(int32(pointer))
	return err
}

// LoadWasmContractFromFile loads a WebAssembly contract from a file
func LoadWasmContractFromFile(filePath string) ([]byte, error) {
	if !filepath.IsAbs(filePath) {
		absPath, err := filepath.Abs(filePath)
		if err != nil {
			return nil, &WASIError{Message: "failed to resolve absolute path", Cause: err}
		}
		filePath = absPath
	}

	wasmBytes, err := os.ReadFile(filePath)
	if err != nil {
		return nil, &WASIError{Message: "failed to read WebAssembly file", Cause: err}
	}

	return wasmBytes, nil
}

// ExportedFunction represents information about an exported function
type ExportedFunction struct {
	Name            string      `json:"name"`
	Inputs          []ParamDesc `json:"inputs"`
	Outputs         []ParamDesc `json:"outputs"`
	StateMutability string      `json:"stateMutability"`
}

// ParamDesc represents information about a parameter
type ParamDesc struct {
	Name string `json:"name"`
	Type string `json:"type"`
}

// ContractABI represents the ABI information of the contract
type ContractABI struct {
	Functions []ExportedFunction `json:"functions"`
}

// GetExportedFunctions returns a list of exported functions from the Wasm instance
func (w *WasmInstance) GetExportedFunctions() (*ContractABI, error) {
	if w.instance == nil {
		return nil, fmt.Errorf("wasm instance is not initialized")
	}

	abi := &ContractABI{
		Functions: []ExportedFunction{},
	}

	// 获取所有导出函数
	// Wasmer不提供直接获取所有函数名的API，我们需要尝试获取常见的函数
	knownFunctions := []string{
		"init", "query", "execute", "migrate",
		// 尝试获取常见的查询函数
		"query_balance", "query_info", "query_state", "query_config",
		// 尝试获取常见的执行函数
		"execute_transfer", "execute_send", "execute_mint", "execute_burn",
	}

	for _, funcName := range knownFunctions {
		// 尝试获取函数，忽略错误（因为不是所有函数都会存在）
		exportedFunc, err := w.instance.Exports.GetRawFunction(funcName)
		if err != nil || exportedFunc == nil {
			continue
		}

		// 函数存在，提取信息
		funcInfo := ExportedFunction{
			Name: funcName,
		}

		// 根据函数名推断参数和返回类型
		funcInfo.Inputs = inferParamTypes(funcName)
		funcInfo.Outputs = inferReturnTypes(funcName)

		// 确定状态可变性
		if isQueryFunction(funcName) {
			funcInfo.StateMutability = "view"
		} else {
			funcInfo.StateMutability = "nonpayable"
		}

		abi.Functions = append(abi.Functions, funcInfo)
	}

	return abi, nil
}

// inferParamTypes 根据函数名推断参数类型
func inferParamTypes(funcName string) []ParamDesc {
	switch {
	case funcName == "init":
		return []ParamDesc{
			{Name: "msg", Type: "InitMsg"},
		}
	case funcName == "execute":
		return []ParamDesc{
			{Name: "msg", Type: "ExecuteMsg"},
		}
	case funcName == "query":
		return []ParamDesc{
			{Name: "msg", Type: "QueryMsg"},
		}
	case funcName == "migrate":
		return []ParamDesc{
			{Name: "msg", Type: "MigrateMsg"},
		}
	case strings.HasPrefix(funcName, "execute_"):
		return []ParamDesc{
			{Name: "params", Type: "json"},
		}
	case strings.HasPrefix(funcName, "query_"):
		return []ParamDesc{
			{Name: "params", Type: "json"},
		}
	default:
		return []ParamDesc{
			{Name: "params", Type: "bytes"},
		}
	}
}

// inferReturnTypes 根据函数名推断返回类型
func inferReturnTypes(funcName string) []ParamDesc {
	switch {
	case strings.HasPrefix(funcName, "query_"):
		return []ParamDesc{
			{Name: "", Type: "json"},
		}
	case funcName == "query":
		return []ParamDesc{
			{Name: "", Type: "json"},
		}
	case funcName == "execute" || funcName == "init" || funcName == "migrate":
		return []ParamDesc{
			{Name: "", Type: "bool"},
		}
	default:
		return []ParamDesc{
			{Name: "", Type: "bytes"},
		}
	}
}

// isQueryFunction 判断函数是否为查询函数
func isQueryFunction(funcName string) bool {
	return funcName == "query" || strings.HasPrefix(funcName, "query_")
}

// ExtractABI 从WebAssembly字节码中提取ABI信息
func ExtractABI(wasmBytes []byte) (*ContractABI, error) {
	// 创建临时实例以提取信息
	engine := wasmer.NewEngine()
	store := wasmer.NewStore(engine)

	// 编译模块
	module, err := wasmer.NewModule(store, wasmBytes)
	if err != nil {
		return nil, &WASIError{
			Message: "failed to compile WebAssembly module for ABI extraction",
			Cause:   err,
		}
	}

	// 创建空的导入对象
	importObject := wasmer.NewImportObject()

	// 实例化模块
	instance, err := wasmer.NewInstance(module, importObject)
	if err != nil {
		return nil, &WASIError{
			Message: "failed to instantiate WebAssembly module for ABI extraction",
			Cause:   err,
		}
	}

	// 尝试获取内存
	memory, _ := instance.Exports.GetMemory("memory")

	// 创建临时logger
	logger := &dummyLogger{}

	// 创建WasmInstance
	wasmInst := &WasmInstance{
		instance: instance,
		memory:   memory,
		exports:  make(map[string]interface{}),
		logger:   logger,
	}

	// 获取导出函数
	return wasmInst.GetExportedFunctions()
}

// dummyLogger 是一个空的logger实现
type dummyLogger struct{}

// Log 实现Logger接口
func (l *dummyLogger) Log(message string, args ...any) {
	// 不做任何操作
}

// GenerateABIJSON 生成类似以太坊ABI格式的JSON
func (abi *ContractABI) GenerateABIJSON() (string, error) {
	abiJSON, err := json.MarshalIndent(abi.Functions, "", "  ")
	if err != nil {
		return "", fmt.Errorf("failed to marshal ABI to JSON: %w", err)
	}
	return string(abiJSON), nil
}

// GenerateInterfaceDefinition 生成契约接口定义（类似Solidity接口）
func (abi *ContractABI) GenerateInterfaceDefinition(contractName string) string {
	if contractName == "" {
		contractName = "WasmContract"
	}

	var result strings.Builder
	result.WriteString(fmt.Sprintf("interface %s {\n", contractName))

	for _, fn := range abi.Functions {
		// 函数签名
		result.WriteString(fmt.Sprintf("    // %s\n", fn.Name))
		result.WriteString(fmt.Sprintf("    function %s(", fn.Name))

		// 参数列表
		for i, param := range fn.Inputs {
			if i > 0 {
				result.WriteString(", ")
			}
			paramName := param.Name
			if paramName == "" {
				paramName = fmt.Sprintf("param%d", i)
			}
			result.WriteString(fmt.Sprintf("%s %s", paramName, param.Type))
		}
		result.WriteString(")")

		// 返回值
		if len(fn.Outputs) > 0 {
			result.WriteString(" returns (")
			for i, output := range fn.Outputs {
				if i > 0 {
					result.WriteString(", ")
				}
				outputType := output.Type
				result.WriteString(outputType)
			}
			result.WriteString(")")
		}

		// 状态可变性
		if fn.StateMutability != "" {
			result.WriteString(fmt.Sprintf(" %s", fn.StateMutability))
		}

		result.WriteString(";\n\n")
	}

	result.WriteString("}\n")
	return result.String()
}

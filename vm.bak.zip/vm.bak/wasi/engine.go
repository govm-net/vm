// Package wasi provides WASI integration for the VM
package wasi

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// WASIEngine 是 WebAssembly 执行的主引擎
type WASIEngine struct {
	// 配置
	ContractsDir string
	TinyGoPath   string
	DefaultOpts  WASIOptions

	// 编译器
	compiler *WASICompiler

	// 合约存储
	contracts     map[string]string // 合约地址到 WASM 文件路径的映射
	contractsLock sync.RWMutex
}

// DeployOptions 定义部署 WebAssembly 合约的选项
type DeployOptions struct {
	WASIOptions WASIOptions // WebAssembly 执行选项
	AsWASI      bool        // 是否作为 WebAssembly 合约部署
}

// NewWASIEngine 创建一个新的 WebAssembly 执行引擎
func NewWASIEngine(contractsDir, tinyGoPath string) (*WASIEngine, error) {
	// 如果合约目录不存在，则创建
	if err := os.MkdirAll(contractsDir, 0755); err != nil {
		return nil, fmt.Errorf("failed to create contracts directory: %w", err)
	}

	compiler := NewWASICompiler(tinyGoPath, contractsDir)

	return &WASIEngine{
		ContractsDir: contractsDir,
		TinyGoPath:   tinyGoPath,
		DefaultOpts:  DefaultWASIOptions(),
		compiler:     compiler,
		contracts:    make(map[string]string),
	}, nil
}

// DeployContract 部署一个新的 WebAssembly 合约
func (e *WASIEngine) DeployContract(code []byte, options DeployOptions) (string, error) {
	// 编译合约
	wasmBytes, err := e.compiler.CompileContract(code)
	if err != nil {
		return "", fmt.Errorf("failed to compile contract: %w", err)
	}

	// 为合约生成唯一地址
	contractAddr := generateContractAddress("", wasmBytes)

	// 为 WASM 模块创建文件路径
	wasmPath := filepath.Join(e.ContractsDir, contractAddr+".wasm")

	// 将 WASM 模块保存到磁盘
	if err := os.WriteFile(wasmPath, wasmBytes, 0644); err != nil {
		return "", fmt.Errorf("failed to save WASM module: %w", err)
	}

	// 注册合约
	e.contractsLock.Lock()
	e.contracts[contractAddr] = wasmPath
	e.contractsLock.Unlock()

	return contractAddr, nil
}

// ExecuteContract 在已部署的 WebAssembly 合约上执行函数
func (e *WASIEngine) ExecuteContract(ctx WASIContext, contract string, function string, args ...interface{}) (interface{}, error) {
	// 检查合约是否存在
	e.contractsLock.RLock()
	wasmPath, exists := e.contracts[contract]
	e.contractsLock.RUnlock()

	if !exists {
		return nil, fmt.Errorf("contract %s not found", contract)
	}

	// 加载 WASM 模块
	wasmBytes, err := LoadWasmContractFromFile(wasmPath)
	if err != nil {
		return nil, fmt.Errorf("failed to load WASM module: %w", err)
	}

	// 创建新实例
	instance, err := NewWasmInstance(wasmBytes, ctx, e.DefaultOpts)
	if err != nil {
		return nil, fmt.Errorf("failed to create WASM instance: %w", err)
	}
	defer instance.Close()

	// 执行函数
	result, err := instance.Call(function, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to execute function %s: %w", function, err)
	}

	return result, nil
}

// IsWASIContract 检查合约是否是 WebAssembly 合约
func (e *WASIEngine) IsWASIContract(contract string) bool {
	e.contractsLock.RLock()
	_, exists := e.contracts[contract]
	e.contractsLock.RUnlock()
	return exists
}

// LoadContracts 从合约目录加载现有的 WebAssembly 合约
func (e *WASIEngine) LoadContracts() error {
	// 获取合约目录中的所有 .wasm 文件
	pattern := filepath.Join(e.ContractsDir, "*.wasm")
	matches, err := filepath.Glob(pattern)
	if err != nil {
		return fmt.Errorf("failed to list WASM files: %w", err)
	}

	// 注册每个合约
	for _, path := range matches {
		// 从文件名中提取地址
		filename := filepath.Base(path)
		if len(filename) < 6 { // 至少 "x.wasm"
			continue
		}

		addrStr := filename[:len(filename)-5] // 移除 ".wasm"

		// 注册合约
		e.contractsLock.Lock()
		e.contracts[addrStr] = path
		e.contractsLock.Unlock()
	}

	return nil
}

// generateContractAddress 根据部署者地址和合约字节码生成合约地址
func generateContractAddress(sender string, wasmBytes []byte) string {
	// 使用当前时间戳作为随机性源
	timestamp := time.Now().UnixNano()

	// 组合发送者地址、时间戳和字节码的哈希
	hash := sha256.New()
	if sender != "" {
		hash.Write([]byte(sender))
	}
	hash.Write([]byte(fmt.Sprintf("%d", timestamp)))

	// 只使用字节码的哈希，而不是整个字节码，以提高效率
	codeHash := sha256.Sum256(wasmBytes)
	hash.Write(codeHash[:])

	// 生成最终哈希
	finalHash := hash.Sum(nil)

	// 将哈希转换为十六进制字符串作为合约地址，取前 40 个字符
	return hex.EncodeToString(finalHash)[:40]
}

# Wasmer-Go 集成指南

本文档提供了如何将 Wasmer 库集成到 WASI 合约执行系统中的详细说明。由于 Wasmer 可能需要额外的系统依赖，这里提供了一个分步指南，以便在实际生产环境中完成集成。

## 1. 安装 Wasmer Go 库

首先，需要添加 wasmer-go 库作为依赖：

```bash
go get github.com/wasmerio/wasmer-go/wasmer
```

支持的平台：
- Linux (amd64, arm64)
- macOS (amd64, arm64)
- Windows (amd64)

如果在安装过程中遇到问题，请确保已经安装了相关的系统依赖（例如，在 Linux 上可能需要 `libc-dev`）。

## 2. 修改 `module.go` 文件

首先需要定义 `WASIContext` 接口，这将用于连接 WebAssembly 和主机环境：

```go
// WASIContext 定义了用于 WASI 操作的上下文接口
type WASIContext interface {
    // Log 记录消息
    Log(message string)
    // GetInstance 返回当前实例，用于访问 WebAssembly 资源
    GetInstance() interface{}
}
```

然后，更新 `WasmInstance` 结构以使用 Wasmer 组件：

```go
// WasmInstance 表示已加载的 WebAssembly 模块实例
type WasmInstance struct {
    // WebAssembly 组件
    instance    *wasmer.Instance
    memory      *wasmer.Memory
    exports     map[string]interface{}
    store       *wasmer.Store
    engine      *wasmer.Engine
    module      *wasmer.Module
    
    // VM 上下文
    ctx         WASIContext
    
    // 函数缓存
    funcCache   map[string]wasmer.Function
    
    // 同步
    mutex       sync.Mutex
}
```

## 3. 实现 `NewWasmInstance` 方法

```go
func NewWasmInstance(wasmBytes []byte, ctx WASIContext, options WASIOptions) (*WasmInstance, error) {
    // 创建引擎和存储
    engine := wasmer.NewEngine()
    store := wasmer.NewStore(engine)
    
    // 编译模块
    module, err := wasmer.NewModule(store, wasmBytes)
    if err != nil {
        return nil, &WASIError{Message: "failed to compile WebAssembly module", Cause: err}
    }
    
    // 为 VM 函数创建导入对象
    importObject := wasmer.NewImportObject()
    
    // 注册 VM 函数
    vmFunctions := createVMFunctions(ctx, store)
    for name, function := range vmFunctions {
        err := importObject.Register("vm", map[string]wasmer.IntoExtern{
            name: function,
        })
        if err != nil {
            return nil, &WASIError{
                Message: fmt.Sprintf("failed to register VM function %s", name), 
                Cause: err,
            }
        }
    }
    
    // 实例化模块
    instance, err := wasmer.NewInstance(module, importObject)
    if err != nil {
        return nil, &WASIError{Message: "failed to instantiate WebAssembly module", Cause: err}
    }
    
    // 获取内存
    memory, err := instance.Exports.GetMemory("memory")
    if err != nil {
        return nil, &WASIError{Message: "WebAssembly module has no memory export", Cause: err}
    }
    
    // 获取所有导出
    exports := make(map[string]interface{})
    for name, extern := range instance.Exports.GetExtern() {
        exports[name] = extern
    }
    
    return &WasmInstance{
        instance:    instance,
        memory:      memory,
        exports:     exports,
        store:       store,
        engine:      engine,
        module:      module,
        ctx:         ctx,
        funcCache:   make(map[string]wasmer.Function),
    }, nil
}
```

## 4. 内存管理

使用 Wasmer 的内存管理 API 实现内存访问，这些方法应该处理 WebAssembly 模块的线性内存：

```go
// ReadMemory 从 WebAssembly 模块的内存中读取
func (w *WasmInstance) ReadMemory(offset uint32, size uint32) ([]byte, error) {
    if w.memory == nil {
        return nil, errors.New("no memory available")
    }
    
    // 检查边界
    if uint64(offset)+uint64(size) > uint64(w.memory.Size()) {
        return nil, errors.New("memory access out of bounds")
    }
    
    // 获取内存数据并复制它
    data := make([]byte, size)
    copy(data, w.memory.Data()[offset:offset+size])
    return data, nil
}

// WriteMemory 写入 WebAssembly 模块的内存
func (w *WasmInstance) WriteMemory(offset uint32, data []byte) error {
    if w.memory == nil {
        return errors.New("no memory available")
    }
    
    // 检查边界
    if uint64(offset)+uint64(len(data)) > uint64(w.memory.Size()) {
        return errors.New("memory access out of bounds")
    }
    
    // 将数据复制到内存
    copy(w.memory.Data()[offset:], data)
    return nil
}
```

## 5. 函数调用

在 Wasmer 中调用 WebAssembly 函数需要处理参数类型转换和内存管理：

```go
// Call 调用 WebAssembly 模块中的函数
func (w *WasmInstance) Call(functionName string, args ...interface{}) (interface{}, error) {
    w.mutex.Lock()
    defer w.mutex.Unlock()
    
    // 获取函数
    var function wasmer.Function
    var exists bool
    
    // 首先检查缓存
    function, exists = w.funcCache[functionName]
    if !exists {
        // 尝试从导出获取函数
        exportValue, exists := w.exports[functionName]
        if !exists {
            return nil, &WASIError{
                Message: fmt.Sprintf("function %s not found in WebAssembly module", 
                functionName),
            }
        }
        
        // 将导出值转换为函数
        extern, ok := exportValue.(wasmer.IntoExtern)
        if !ok {
            return nil, &WASIError{
                Message: fmt.Sprintf("export %s is not a valid extern", 
                functionName),
            }
        }
        
        function, ok = extern.IntoFunction()
        if !ok {
            return nil, &WASIError{
                Message: fmt.Sprintf("export %s is not a function", 
                functionName),
            }
        }
        
        // 缓存函数
        w.funcCache[functionName] = function
    }
    
    // 获取函数签名
    funcType := function.Type()
    paramTypes := funcType.Params()
    resultTypes := funcType.Results()
    
    // 检查参数数量
    if len(paramTypes) != len(args) {
        return nil, &WASIError{
            Message: fmt.Sprintf("function %s expects %d parameters, got %d", 
                functionName, len(paramTypes), len(args)),
        }
    }
    
    // 准备参数
    wasmArgs := make([]wasmer.Value, len(args))
    for i, arg := range args {
        wasmValue, err := w.convertGoValueToWasm(arg, paramTypes[i].Kind())
        if err != nil {
            return nil, &WASIError{
                Message: fmt.Sprintf("failed to convert argument %d for function %s", 
                i, functionName),
                Cause: err,
            }
        }
        wasmArgs[i] = wasmValue
    }
    
    // 调用函数
    results, err := function.Call(wasmArgs...)
    if err != nil {
        return nil, &WASIError{
            Message: fmt.Sprintf("error calling function %s", functionName), 
            Cause: err,
        }
    }
    
    // 将结果转换回 Go 值
    if len(resultTypes) == 0 || len(results) == 0 {
        return nil, nil
    } else if len(resultTypes) == 1 {
        return w.convertWasmValueToGo(results[0], resultTypes[0].Kind())
    } else {
        // 多返回值
        goResults := make([]interface{}, len(results))
        for i, result := range results {
            goValue, err := w.convertWasmValueToGo(result, resultTypes[i].Kind())
            if err != nil {
                return nil, &WASIError{
                    Message: fmt.Sprintf(
                        "failed to convert result %d from function %s", 
                        i, functionName),
                    Cause: err,
                }
            }
            goResults[i] = goValue
        }
        return goResults, nil
    }
}
```

## 6. 类型转换

实现 Go 和 WebAssembly 值之间的转换：

```go
// convertGoValueToWasm 将 Go 值转换为 Wasmer 值
func (w *WasmInstance) convertGoValueToWasm(value interface{}, kind wasmer.ValueKind) (wasmer.Value, error) {
    switch kind {
    case wasmer.I32:
        // 处理各种应转换为 I32 的整数类型
        switch v := value.(type) {
        case int:
            return wasmer.NewI32(int32(v)), nil
        case int8:
            return wasmer.NewI32(int32(v)), nil
        case int16:
            return wasmer.NewI32(int32(v)), nil
        case int32:
            return wasmer.NewI32(v), nil
        case uint:
            return wasmer.NewI32(int32(v)), nil
        case uint8:
            return wasmer.NewI32(int32(v)), nil
        case uint16:
            return wasmer.NewI32(int32(v)), nil
        case uint32:
            return wasmer.NewI32(int32(v)), nil
        case bool:
            if v {
                return wasmer.NewI32(1), nil
            }
            return wasmer.NewI32(0), nil
        case string:
            // 对于字符串，我们需要在 WebAssembly 实例中分配内存
            ptr, err := w.stringToWasm(v)
            if err != nil {
                return wasmer.Value{}, err
            }
            return wasmer.NewI32(int32(ptr)), nil
        }
    case wasmer.I64:
        // 处理各种应转换为 I64 的整数类型
        switch v := value.(type) {
        case int:
            return wasmer.NewI64(int64(v)), nil
        case int8:
            return wasmer.NewI64(int64(v)), nil
        case int16:
            return wasmer.NewI64(int64(v)), nil
        case int32:
            return wasmer.NewI64(int64(v)), nil
        case int64:
            return wasmer.NewI64(v), nil
        case uint:
            return wasmer.NewI64(int64(v)), nil
        case uint8:
            return wasmer.NewI64(int64(v)), nil
        case uint16:
            return wasmer.NewI64(int64(v)), nil
        case uint32:
            return wasmer.NewI64(int64(v)), nil
        case uint64:
            return wasmer.NewI64(int64(v)), nil
        }
    case wasmer.F32:
        // 处理浮点类型
        switch v := value.(type) {
        case float32:
            return wasmer.NewF32(v), nil
        case float64:
            return wasmer.NewF32(float32(v)), nil
        }
    case wasmer.F64:
        // 处理浮点类型
        switch v := value.(type) {
        case float32:
            return wasmer.NewF64(float64(v)), nil
        case float64:
            return wasmer.NewF64(v), nil
        }
    }
    
    return wasmer.Value{}, fmt.Errorf(
        "unsupported value type %T for WebAssembly kind %v", value, kind)
}

// convertWasmValueToGo 将 Wasmer 值转换为 Go 值
func (w *WasmInstance) convertWasmValueToGo(value wasmer.Value, kind wasmer.ValueKind) (interface{}, error) {
    switch kind {
    case wasmer.I32:
        return value.I32(), nil
    case wasmer.I64:
        return value.I64(), nil
    case wasmer.F32:
        return value.F32(), nil
    case wasmer.F64:
        return value.F64(), nil
    default:
        return nil, fmt.Errorf("unsupported WebAssembly kind: %v", kind)
    }
}
```

## 7. 注意事项与最佳实践

在集成 Wasmer 时，需要注意以下几点：

1. **内存管理**：WebAssembly 内存在调用之间是持久的，确保适当地分配和释放内存。
2. **错误处理**：适当地捕获并处理来自 WebAssembly 函数的错误。
3. **类型安全**：确保在 Go 和 WebAssembly 之间传递参数时保持类型安全。
4. **并发考虑**：如果多个 goroutine 访问同一个 WebAssembly 实例，请使用互斥锁保护内存访问。
5. **资源释放**：在不再需要 WebAssembly 实例时，使用 `Close()` 方法释放资源。

## 8. 更新日志

在 Wasmer Go 库的新版本发布时，可能需要更新集成代码以适应 API 更改。请参考 Wasmer 的官方文档以获取详细信息：

- [Wasmer Go 文档](https://pkg.go.dev/github.com/wasmerio/wasmer-go/wasmer)
- [Wasmer GitHub 存储库](https://github.com/wasmerio/wasmer-go)

## 结论

通过遵循本文档中的指导，您应该能够成功地将 Wasmer 集成到 WASI 合约执行系统中。这将允许系统高效地执行用 Go 编写并编译为 WebAssembly 的智能合约。 
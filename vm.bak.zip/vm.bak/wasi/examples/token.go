// Package token contains a simple token contract.
package token

import (
	"errors"
	"fmt"
	"math/big"
)

// TokenContract 表示一个简单的代币合约
type TokenContract struct {
	// 余额映射 - 地址到余额
	balances map[string]*big.Int

	// 代币名称
	name string

	// 代币符号
	symbol string

	// 小数位数
	decimals uint8

	// 合约拥有者
	owner string

	// 总供应量
	totalSupply *big.Int
}

// NewToken 创建一个新的代币合约实例
func NewToken() *TokenContract {
	return &TokenContract{
		balances:    make(map[string]*big.Int),
		name:        "Example Token",
		symbol:      "EXTKN",
		decimals:    18,
		owner:       "",
		totalSupply: big.NewInt(0),
	}
}

// Init 初始化代币合约
func (t *TokenContract) Init(owner string, initialSupply *big.Int) error {
	if owner == "" {
		return errors.New("owner address cannot be empty")
	}

	t.owner = owner

	// 铸造初始供应量
	if initialSupply.Cmp(big.NewInt(0)) > 0 {
		return t.Mint(owner, initialSupply)
	}

	return nil
}

// Name 返回代币名称
func (t *TokenContract) Name() string {
	return t.name
}

// Symbol 返回代币符号
func (t *TokenContract) Symbol() string {
	return t.symbol
}

// Decimals 返回代币小数位数
func (t *TokenContract) Decimals() uint8 {
	return t.decimals
}

// TotalSupply 返回代币总供应量
func (t *TokenContract) TotalSupply() *big.Int {
	return new(big.Int).Set(t.totalSupply)
}

// BalanceOf 返回指定地址的余额
func (t *TokenContract) BalanceOf(address string) *big.Int {
	if balance, ok := t.balances[address]; ok {
		return new(big.Int).Set(balance)
	}
	return big.NewInt(0)
}

// Transfer 从调用者地址转移代币到指定地址
func (t *TokenContract) Transfer(from, to string, amount *big.Int) error {
	if from == "" {
		return errors.New("sender address cannot be empty")
	}
	if to == "" {
		return errors.New("recipient address cannot be empty")
	}
	if amount.Cmp(big.NewInt(0)) <= 0 {
		return errors.New("amount must be positive")
	}

	// 检查余额
	fromBalance := t.BalanceOf(from)
	if fromBalance.Cmp(amount) < 0 {
		return errors.New("insufficient balance")
	}

	// 更新余额
	t.balances[from] = new(big.Int).Sub(fromBalance, amount)
	toBalance := t.BalanceOf(to)
	t.balances[to] = new(big.Int).Add(toBalance, amount)

	// 记录事件
	fmt.Printf("Transfer: %s -> %s: %s\n", from, to, amount.String())

	return nil
}

// Mint 铸造新代币并分配给指定地址
func (t *TokenContract) Mint(to string, amount *big.Int) error {
	// 只有拥有者可以铸造
	if t.owner == "" {
		return errors.New("contract owner not set")
	}

	if to == "" {
		return errors.New("recipient address cannot be empty")
	}
	if amount.Cmp(big.NewInt(0)) <= 0 {
		return errors.New("amount must be positive")
	}

	// 更新余额
	toBalance := t.BalanceOf(to)
	t.balances[to] = new(big.Int).Add(toBalance, amount)

	// 更新总供应量
	t.totalSupply = new(big.Int).Add(t.totalSupply, amount)

	// 记录事件
	fmt.Printf("Mint: %s: %s\n", to, amount.String())

	return nil
}

// Burn 从指定地址销毁代币
func (t *TokenContract) Burn(from string, amount *big.Int) error {
	if from == "" {
		return errors.New("address cannot be empty")
	}
	if amount.Cmp(big.NewInt(0)) <= 0 {
		return errors.New("amount must be positive")
	}

	// 检查余额
	fromBalance := t.BalanceOf(from)
	if fromBalance.Cmp(amount) < 0 {
		return errors.New("insufficient balance")
	}

	// 更新余额
	t.balances[from] = new(big.Int).Sub(fromBalance, amount)

	// 更新总供应量
	t.totalSupply = new(big.Int).Sub(t.totalSupply, amount)

	// 记录事件
	fmt.Printf("Burn: %s: %s\n", from, amount.String())

	return nil
}

// Owner 返回合约拥有者
func (t *TokenContract) Owner() string {
	return t.owner
}

// TransferOwnership 转移合约拥有权
func (t *TokenContract) TransferOwnership(from, to string) error {
	if from != t.owner {
		return errors.New("only owner can transfer ownership")
	}
	if to == "" {
		return errors.New("new owner address cannot be empty")
	}

	t.owner = to

	// 记录事件
	fmt.Printf("OwnershipTransferred: %s -> %s\n", from, to)

	return nil
}

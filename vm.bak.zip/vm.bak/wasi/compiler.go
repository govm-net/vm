// Package wasi provides WebAssembly compilation and execution functionality
package wasi

import (
	"bytes"
	"compress/gzip"
	"errors"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"io/ioutil"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"unicode"
)

// ParamInfo stores information about a function parameter
type ParamInfo struct {
	Name string
	Type string
}

// FunctionInfo stores information about an exported function
type FunctionInfo struct {
	Name       string
	Params     []ParamInfo
	ReturnType string
	IsExported bool
}

// WASICompiler handles the compilation of Go source code to WebAssembly modules
type WASICompiler struct {
	// TinyGo executable path
	TinyGoPath string

	// Output directory for compiled contracts
	OutputDir string

	// Allowed imports
	AllowedImports []string

	// Maximum source code size (bytes)
	MaxSourceSize int64

	// Maximum compiled output size (bytes)
	MaxCompiledSize int64

	// Temporary directory (if empty, use system temporary directory)
	TempDir string

	// Keep temporary files (for debugging)
	KeepTemp bool
}

// NewWASICompiler creates a new WebAssembly compiler instance
func NewWASICompiler(tinyGoPath string, outputDir string) *WASICompiler {
	// If no TinyGo path is specified, try to find it in PATH
	if tinyGoPath == "" {
		path, err := exec.LookPath("tinygo")
		if err == nil {
			tinyGoPath = path
		} else {
			// Use default path
			tinyGoPath = "tinygo"
		}
	}

	return &WASICompiler{
		TinyGoPath: tinyGoPath,
		OutputDir:  outputDir,
		AllowedImports: []string{
			"errors",
			"fmt",
			"math",
			"math/big",
			"strconv",
			"strings",
			"bytes",
			"encoding/json",
			"encoding/hex",
			"crypto/sha256",
		},
		MaxSourceSize:   1024 * 1024,      // 1MB
		MaxCompiledSize: 10 * 1024 * 1024, // 10MB
	}
}

// CompileContract compiles Go source code to a WebAssembly module
func (c *WASICompiler) CompileContract(source []byte) ([]byte, error) {
	// Check if source code is GZIP compressed
	if len(source) > 2 && source[0] == 0x1f && source[1] == 0x8b {
		// Decompress source code
		gzipReader, err := gzip.NewReader(bytes.NewReader(source))
		if err != nil {
			return nil, &WASIError{Message: "failed to decompress source code", Cause: err}
		}
		defer gzipReader.Close()

		decompressed, err := ioutil.ReadAll(gzipReader)
		if err != nil {
			return nil, &WASIError{Message: "failed to read decompressed source code", Cause: err}
		}
		source = decompressed
	}

	// Validate contract source code
	if err := c.ValidateContract(source); err != nil {
		return nil, err
	}

	// Extract package name and exported functions
	packageName, exportedFunctions, err := c.extractContractInfo(source)
	if err != nil {
		return nil, &WASIError{Message: "failed to extract contract information", Cause: err}
	}

	// If no exported functions, return error
	if len(exportedFunctions) == 0 {
		return nil, &WASIError{Message: "contract must export at least one public function (starting with uppercase letter)"}
	}

	// Generate WASI wrapper code
	wrapperCode, err := c.generateWASIWrapper(packageName, exportedFunctions)
	if err != nil {
		return nil, &WASIError{Message: "failed to generate WASI wrapper", Cause: err}
	}

	// Prepare compilation environment
	tempDir, err := c.prepareCompilationEnvironment(source, wrapperCode)
	if err != nil {
		return nil, &WASIError{Message: "failed to prepare compilation environment", Cause: err}
	}

	// If temporary files are not kept, delete temp directory when done
	if !c.KeepTemp {
		defer os.RemoveAll(tempDir)
	}

	// Compile with TinyGo
	wasmBytes, err := c.compileWithTinyGo(tempDir)
	if err != nil {
		return nil, err
	}

	return wasmBytes, nil
}

// ValidateContract validates the contract source code
func (c *WASICompiler) ValidateContract(source []byte) error {
	// Check source code size
	if int64(len(source)) > c.MaxSourceSize {
		return &WASIError{
			Message: fmt.Sprintf("source code exceeds maximum size limit of %d bytes", c.MaxSourceSize),
		}
	}

	// Check if source code contains Go package declaration
	if !bytes.Contains(source, []byte("package ")) {
		return &WASIError{Message: "source code does not contain a valid Go package declaration"}
	}

	// Check if it contains exported functions (functions starting with uppercase letter)
	hasExportedFunc := regexp.MustCompile(`func\s+([A-Z][a-zA-Z0-9_]*)\s*\(`).Match(source)
	if !hasExportedFunc {
		return &WASIError{Message: "source code does not contain any exported functions (must start with uppercase letter)"}
	}

	// Check if using disallowed imports
	importRegex := regexp.MustCompile(`import\s+\(\s*((?:.|\n)*?)\s*\)`)
	singleImportRegex := regexp.MustCompile(`import\s+"([^"]+)"`)

	// Build allowed imports map for quick lookup
	allowedImportsMap := make(map[string]bool)
	for _, pkg := range c.AllowedImports {
		allowedImportsMap[pkg] = true
	}

	// Check multi-line imports
	importMatches := importRegex.FindAllSubmatch(source, -1)
	for _, match := range importMatches {
		if len(match) > 1 {
			imports := bytes.Split(match[1], []byte("\n"))
			for _, imp := range imports {
				// Clean and extract package name
				cleanImp := bytes.TrimSpace(imp)
				if len(cleanImp) == 0 || bytes.HasPrefix(cleanImp, []byte("//")) {
					continue
				}

				// Extract quoted package name
				pkgMatch := regexp.MustCompile(`"([^"]+)"`).FindSubmatch(cleanImp)
				if len(pkgMatch) > 1 {
					pkg := string(pkgMatch[1])
					// Check if it's allowed
					allowed := false
					for allowedPkg := range allowedImportsMap {
						if pkg == allowedPkg || strings.HasPrefix(pkg, allowedPkg+"/") {
							allowed = true
							break
						}
					}
					if !allowed {
						return &WASIError{
							Message: fmt.Sprintf("import of package %q is not allowed", pkg),
						}
					}
				}
			}
		}
	}

	// Check single-line imports
	singleImportMatches := singleImportRegex.FindAllSubmatch(source, -1)
	for _, match := range singleImportMatches {
		if len(match) > 1 {
			pkg := string(match[1])
			// Check if it's allowed
			allowed := false
			for allowedPkg := range allowedImportsMap {
				if pkg == allowedPkg || strings.HasPrefix(pkg, allowedPkg+"/") {
					allowed = true
					break
				}
			}
			if !allowed {
				return &WASIError{
					Message: fmt.Sprintf("import of package %q is not allowed", pkg),
				}
			}
		}
	}

	// Check if using restricted syntax or keywords
	restrictedPatterns := []struct {
		pattern string
		message string
	}{
		{`\bunsafe\b`, "use of 'unsafe' package is not allowed"},
		{`\bgo\s+func\b`, "goroutines are not allowed in contracts"},
		{`\bgo\s+\w+\(`, "goroutines are not allowed in contracts"},
		{`\bcgo\b`, "cgo is not allowed in contracts"},
		{`\bsyscall\b`, "syscall is not allowed in contracts"},
		{`\bos\.\b`, "os package is not allowed in contracts"},
		{`\bnet\.\b`, "net package is not allowed in contracts"},
		{`\bhttp\.\b`, "http package is not allowed in contracts"},
		{`\bioutil\.\b`, "ioutil package is not allowed in contracts"},
		{`\bexec\.\b`, "exec package is not allowed in contracts"},
	}

	for _, rp := range restrictedPatterns {
		match, err := regexp.Match(rp.pattern, source)
		if err != nil {
			return &WASIError{Message: "failed to check source code restrictions", Cause: err}
		}
		if match {
			return &WASIError{Message: rp.message}
		}
	}

	return nil
}

// extractContractInfo extracts package name and exported functions from the source code
func (c *WASICompiler) extractContractInfo(source []byte) (string, []FunctionInfo, error) {
	fset := token.NewFileSet()
	f, err := parser.ParseFile(fset, "", source, parser.ParseComments)
	if err != nil {
		return "", nil, &WASIError{Message: "failed to parse Go source code", Cause: err}
	}

	packageName := f.Name.Name
	var exportedFunctions []FunctionInfo

	// Iterate over all declarations
	for _, decl := range f.Decls {
		switch d := decl.(type) {
		case *ast.FuncDecl:
			// Check if function name starts with uppercase (public function)
			if len(d.Name.Name) > 0 && unicode.IsUpper(rune(d.Name.Name[0])) {
				// Extract parameter info
				var params []ParamInfo
				if d.Type.Params != nil && d.Type.Params.List != nil {
					for _, field := range d.Type.Params.List {
						paramType := string(source[field.Type.Pos()-1 : field.Type.End()-1])
						// For named parameters
						if len(field.Names) > 0 {
							for _, name := range field.Names {
								params = append(params, ParamInfo{
									Name: name.Name,
									Type: paramType,
								})
							}
						} else {
							// Anonymous parameters
							params = append(params, ParamInfo{
								Name: "",
								Type: paramType,
							})
						}
					}
				}

				// Extract return value type
				returnType := ""
				if d.Type.Results != nil && d.Type.Results.List != nil {
					if len(d.Type.Results.List) == 1 {
						// Single return value
						returnType = string(source[d.Type.Results.List[0].Type.Pos()-1 : d.Type.Results.List[0].Type.End()-1])
					} else {
						// Multiple return values
						returnType = "(" + string(source[d.Type.Results.Pos()-1:d.Type.Results.End()-1]) + ")"
					}
				}

				exportedFunctions = append(exportedFunctions, FunctionInfo{
					Name:       d.Name.Name,
					Params:     params,
					ReturnType: returnType,
					IsExported: true,
				})
			}
		}
	}

	return packageName, exportedFunctions, nil
}

// generateWASIWrapper generates the WASI wrapper code for the contract
func (c *WASICompiler) generateWASIWrapper(packageName string, functions []FunctionInfo) (string, error) {
	// Build wrapper code
	var buf bytes.Buffer

	// Wrapper package declaration and imports
	buf.WriteString("// Code generated by WASI Compiler. DO NOT EDIT.\n\n")
	buf.WriteString("package main\n\n")
	buf.WriteString("import (\n")
	buf.WriteString(fmt.Sprintf("\t\"%s\" // Original contract package\n", packageName))
	buf.WriteString(")\n\n")

	// Generate wrapper function for each exported function
	for _, fn := range functions {
		// Function signature
		buf.WriteString(fmt.Sprintf("//export %s\n", fn.Name))
		buf.WriteString(fmt.Sprintf("func %s(", fn.Name))

		// Parameter list
		for i, param := range fn.Params {
			if i > 0 {
				buf.WriteString(", ")
			}
			if param.Name != "" {
				buf.WriteString(param.Name)
			} else {
				buf.WriteString(fmt.Sprintf("arg%d", i))
			}
			buf.WriteString(" ")
			buf.WriteString(param.Type)
		}
		buf.WriteString(")")

		// Return type
		if fn.ReturnType != "" {
			buf.WriteString(" ")
			buf.WriteString(fn.ReturnType)
		}
		buf.WriteString(" {\n")

		// Function body - call original contract package function
		if fn.ReturnType != "" && fn.ReturnType != "()" {
			buf.WriteString("\treturn ")
		} else {
			buf.WriteString("\t")
		}

		buf.WriteString(packageName)
		buf.WriteString(".")
		buf.WriteString(fn.Name)
		buf.WriteString("(")

		// Pass parameters
		for i, param := range fn.Params {
			if i > 0 {
				buf.WriteString(", ")
			}
			if param.Name != "" {
				buf.WriteString(param.Name)
			} else {
				buf.WriteString(fmt.Sprintf("arg%d", i))
			}
		}
		buf.WriteString(")\n")
		buf.WriteString("}\n\n")
	}

	// Add main function (WASI contract requires)
	buf.WriteString("func main() {\n")
	buf.WriteString("\t// This function is required by TinyGo WebAssembly compilation\n")
	buf.WriteString("\t// But it will not be called in practice\n")
	buf.WriteString("}\n")

	return buf.String(), nil
}

// prepareCompilationEnvironment creates a temporary directory with the necessary files for compilation
func (c *WASICompiler) prepareCompilationEnvironment(source []byte, wrapperCode string) (string, error) {
	// Create temporary directory
	tempDir, err := os.MkdirTemp(c.TempDir, "wasi-compile-")
	if err != nil {
		return "", &WASIError{Message: "failed to create temporary directory", Cause: err}
	}

	// Create src directory structure
	srcDir := filepath.Join(tempDir, "src")
	if err := os.MkdirAll(srcDir, 0755); err != nil {
		os.RemoveAll(tempDir)
		return "", &WASIError{Message: "failed to create src directory", Cause: err}
	}

	// Write original contract code
	contractFile := filepath.Join(srcDir, "contract.go")
	if err := os.WriteFile(contractFile, source, 0644); err != nil {
		os.RemoveAll(tempDir)
		return "", &WASIError{Message: "failed to write contract file", Cause: err}
	}

	// Write wrapper code
	wrapperFile := filepath.Join(srcDir, "wasi_wrapper.go")
	if err := os.WriteFile(wrapperFile, []byte(wrapperCode), 0644); err != nil {
		os.RemoveAll(tempDir)
		return "", &WASIError{Message: "failed to write wrapper file", Cause: err}
	}

	// Create go.mod file
	goModContent := "module wasi_contract\n\ngo 1.17\n"
	goModFile := filepath.Join(srcDir, "go.mod")
	if err := os.WriteFile(goModFile, []byte(goModContent), 0644); err != nil {
		os.RemoveAll(tempDir)
		return "", &WASIError{Message: "failed to write go.mod file", Cause: err}
	}

	return tempDir, nil
}

// compileWithTinyGo compiles the project with TinyGo to WebAssembly
func (c *WASICompiler) compileWithTinyGo(tempDir string) ([]byte, error) {
	srcDir := filepath.Join(tempDir, "src")
	outputFile := filepath.Join(tempDir, "contract.wasm")

	// Build TinyGo command
	cmd := exec.Command(
		c.TinyGoPath,
		"build",
		"-o", outputFile,
		"-target=wasi",
		"-gc=leaking",
		"-opt=2",
		"-no-debug",
		".",
	)

	// Set working directory
	cmd.Dir = srcDir

	// Capture standard output and error output
	var stderr, stdout bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	// Run compilation
	err := cmd.Run()
	if err != nil {
		return nil, &WASIError{
			Message: "TinyGo compilation failed",
			Cause:   fmt.Errorf("%s: %s", err, stderr.String()),
		}
	}

	// Read the generated WASM file
	wasmBytes, err := os.ReadFile(outputFile)
	if err != nil {
		return nil, &WASIError{Message: "failed to read compiled WebAssembly file", Cause: err}
	}

	// Check compiled output size
	if int64(len(wasmBytes)) > c.MaxCompiledSize {
		return nil, &WASIError{
			Message: fmt.Sprintf("compiled WebAssembly exceeds maximum size limit of %d bytes", c.MaxCompiledSize),
		}
	}

	return wasmBytes, nil
}

// validateWasmModule checks if the data is a valid WebAssembly module
func validateWasmModule(wasmBytes []byte) error {
	// Check WebAssembly magic number: \0asm
	if len(wasmBytes) < 8 {
		return errors.New("invalid WebAssembly module: missing magic header")
	}
	if wasmBytes[0] != 0x00 || wasmBytes[1] != 0x61 || wasmBytes[2] != 0x73 || wasmBytes[3] != 0x6d {
		return errors.New("invalid WebAssembly module: missing magic header")
	}

	// Check version number (current version is 1)
	if wasmBytes[4] != 0x01 || wasmBytes[5] != 0x00 || wasmBytes[6] != 0x00 || wasmBytes[7] != 0x00 {
		return errors.New("invalid WebAssembly module: unsupported version")
	}

	// Here you can add more complex WebAssembly validation logic
	// For example: check for specific sections, validate exported functions, etc.

	return nil
}

# WASI 合约执行流程图 (Wasmer 集成版)

## Wasmer 集成架构

```mermaid
graph TD
    A[用户代码] --> B[TinyGo 编译器]
    B --> C[WebAssembly 字节码]
    C --> D[Wasmer 运行时]
    D --> E[WASI 模块]
    E --> F[VM 执行引擎]
    
    subgraph "Wasmer 集成组件"
        D
        E
        G[内存管理]
        H[导出函数]
        I[主机函数]
    end
    
    G --- D
    H --- D
    I --- D
```

## Wasmer 初始化流程

```mermaid
sequenceDiagram
    participant User as 用户/VM引擎
    participant Integration as WASI集成层
    participant Module as Wasmer模块
    participant Engine as Wasmer引擎
    
    User->>Integration: 提供WebAssembly字节码
    Integration->>Module: 创建NewWasmInstance
    Module->>Engine: 创建Wasmer引擎
    Module->>Engine: 创建存储(Store)
    Module->>Engine: 编译模块
    Module->>Engine: 创建导入对象
    Module->>Engine: 实例化模块
    Module->>Engine: 获取内存导出
    Module->>Engine: 映射导出函数
    Module-->>Integration: 返回WasmInstance实例
    Integration-->>User: 返回准备好的合约实例
```

## 合约调用流程 (Wasmer 版)

```mermaid
flowchart TD
    A[开始执行合约函数] --> B{验证合约地址}
    B -->|无效| C[返回地址错误]
    B -->|有效| D[查找已加载的合约]
    D -->|不存在| E[加载合约]
    D -->|存在| F[调用Call方法]
    E --> F
    
    F --> G[锁定实例]
    G --> H{函数是否存在}
    H -->|否| I[返回函数不存在错误]
    H -->|是| J[转换参数]
    
    J --> K[获取Wasmer函数]
    K --> L[执行Wasmer函数]
    L --> M[转换返回值]
    M --> N[解锁实例]
    N --> O[返回结果]
```

## 内存管理流程 (Wasmer 版)

```mermaid
flowchart TD
    subgraph "读取内存"
        A1[ReadMemory] --> B1{内存是否可用}
        B1 -->|否| C1[返回错误]
        B1 -->|是| D1{边界检查}
        D1 -->|越界| E1[返回错误]
        D1 -->|安全| F1[复制内存数据]
        F1 --> G1[返回字节数据]
    end
    
    subgraph "写入内存"
        A2[WriteMemory] --> B2{内存是否可用}
        B2 -->|否| C2[返回错误]
        B2 -->|是| D2{边界检查}
        D2 -->|越界| E2[返回错误]
        D2 -->|安全| F2[写入内存数据]
        F2 --> G2[返回成功]
    end
    
    subgraph "分配内存"
        A3[AllocateMemory] --> B3[调用allocate导出函数]
        B3 --> C3[获取返回的指针]
        C3 --> D3[返回内存指针]
    end
    
    subgraph "释放内存"
        A4[FreeMemory] --> B4[调用deallocate导出函数]
        B4 --> C4[返回结果]
    end
```

## 函数调用参数转换流程

```mermaid
flowchart LR
    A[Go参数] --> B[类型检查]
    B --> C{参数类型}
    C -->|整数| D[转换为i32/i64]
    C -->|浮点数| E[转换为f32/f64]
    C -->|字符串| F[写入内存并传递指针/长度]
    C -->|字节数组| G[写入内存并传递指针/长度]
    C -->|复杂类型| H[序列化后写入内存]
    
    D --> I[传递给Wasmer函数]
    E --> I
    F --> I
    G --> I
    H --> I
    
    I --> J[执行函数]
    J --> K[获取结果]
    K --> L{结果类型}
    L -->|基本类型| M[直接转换]
    L -->|内存指针| N[从内存读取]
    
    M --> O[返回Go值]
    N --> O
```

## 合约生命周期管理

```mermaid
stateDiagram-v2
    [*] --> 未编译
    未编译 --> 已编译: TinyGo编译
    已编译 --> 已加载: Wasmer加载
    已加载 --> 执行中: 调用函数
    执行中 --> 已加载: 执行完成
    已加载 --> 已卸载: 关闭实例
    已卸载 --> [*]
    
    执行中 --> 错误: 执行异常
    错误 --> 已加载: 恢复
    执行中 --> 超时: 执行超时
    超时 --> 已加载: 中断执行
```

## 地址转换流程 (Wasmer 版)

```mermaid
flowchart TD
    A[16进制字符串地址] --> B[调用AddressFromHexString]
    B --> C{格式验证}
    C -->|无效| D[返回错误]
    C -->|有效| E[调用core.AddressFromString]
    E --> F[返回core.Address]

    G[core.Address] --> H[调用Address.String]
    H --> I[返回16进制字符串]
```

## Wasmer 与 WASI 集成架构

```mermaid
graph TD
    A[VM引擎] --> B[WASIIntegration]
    B --> C[WasmInstance]
    
    C --> D[Wasmer Instance]
    C --> E[内存管理]
    C --> F[函数调用]
    
    D --> G[WebAssembly模块]
    
    subgraph "VM引擎与WASI交互"
        A
        B
        H[合约部署接口]
        I[合约调用接口]
    end
    
    H --- B
    I --- B
    
    subgraph "Wasmer组件"
        D
        J[Wasmer Engine]
        K[Wasmer Store]
        L[Wasmer Memory]
    end
    
    J --- D
    K --- D
    L --- D
    
    subgraph "WASI模块"
        C
        E
        F
        M[错误处理]
    end
``` 
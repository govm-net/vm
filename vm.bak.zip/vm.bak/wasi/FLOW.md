# WASI 合约执行流程图

本文档使用 Mermaid 流程图展示 WASI 合约的编译、部署和执行流程，便于开发人员理解整个系统的工作原理。

## 1. WASI 合约编译流程

```mermaid
flowchart TD
    A[开始编译] --> B[验证Go源代码]
    B -->|不通过| C[返回验证错误]
    B -->|通过| D[提取合约信息]
    D --> E[生成WASI包装代码]
    E --> F[准备编译环境]
    F --> G[使用TinyGo编译]
    G -->|失败| H[返回编译错误]
    G -->|成功| I[验证WebAssembly模块]
    I -->|不通过| J[返回模块验证错误]
    I -->|通过| K[返回WebAssembly字节码]
    K --> L[结束编译]
    
    subgraph 提取合约信息过程
    D1[解析Go文件AST] --> D2[提取包名]
    D2 --> D3[识别导出函数]
    D3 --> D4[提取函数签名信息]
    D4 --> D5[记录参数和返回类型]
    end
    
    subgraph 编译环境准备
    F1[创建临时目录] --> F2[写入原始合约代码]
    F2 --> F3[写入WASI包装代码]
    F3 --> F4[生成go.mod文件]
    end
    
    D --> D1
    F --> F1
```

## 2. WASI 合约部署流程

```mermaid
flowchart TD
    A[开始部署] --> B[验证WebAssembly字节码]
    B -->|不通过| C[返回验证错误]
    B -->|通过| D[生成合约地址]
    D --> E[保存合约字节码]
    E --> F[初始化合约状态]
    F --> G[调用合约初始化函数]
    G -->|失败| H[回滚部署]
    G -->|成功| I[记录部署事件]
    I --> J[返回合约地址]
    J --> K[结束部署]
    
    subgraph 合约地址生成
    D1[使用部署者地址] --> D2[加入时间戳]
    D2 --> D3[加入随机nonce]
    D3 --> D4[计算哈希]
    end
    
    D --> D1
```

## 3. WASI 合约执行流程

```mermaid
flowchart TD
    A[开始执行] --> B[验证合约地址]
    B -->|无效| C[返回合约不存在错误]
    B -->|有效| D[加载合约字节码]
    D --> E[创建WebAssembly实例]
    E --> F[准备函数参数]
    F --> G[调用合约函数]
    G -->|异常| H[捕获并返回执行错误]
    G -->|成功| I[处理函数返回值]
    I --> J[更新合约状态]
    J --> K[记录执行事件]
    K --> L[返回执行结果]
    L --> M[结束执行]
    
    subgraph WebAssembly实例创建
    E1[配置WASI环境] --> E2[注册VM导入函数]
    E2 --> E3[实例化WebAssembly模块]
    E3 --> E4[初始化内存和导出函数]
    end
    
    subgraph 函数参数准备
    F1[序列化复杂参数] --> F2[分配WebAssembly内存]
    F2 --> F3[写入参数数据]
    F3 --> F4[转换为WebAssembly值类型]
    end
    
    E --> E1
    F --> F1
```

## 4. WASI 与 VM 引擎集成流程

```mermaid
flowchart TD
    A[VM引擎接收请求] --> B[解析请求类型]
    
    B -->|部署请求| C[检查源代码类型]
    C -->|Go合约| D[使用WASI编译器]
    C -->|其他合约| E[使用标准编译器]
    D --> F[调用WASI部署流程]
    E --> G[调用标准部署流程]
    F --> H[返回部署结果]
    G --> H
    
    B -->|执行请求| I[检查合约类型]
    I -->|WASI合约| J[使用WASI执行引擎]
    I -->|其他合约| K[使用标准执行引擎]
    J --> L[调用WASI执行流程]
    K --> M[调用标准执行流程]
    L --> N[返回执行结果]
    M --> N
    
    H --> O[结束请求处理]
    N --> O
```

## 5. 数据流转换过程

```mermaid
flowchart LR
    A[Go类型] <-->|类型转换| B[WebAssembly类型]
    
    subgraph Go类型
    A1[整数类型] 
    A2[浮点类型]
    A3[字符串]
    A4[结构体]
    A5[切片/数组]
    end
    
    subgraph WebAssembly类型
    B1[i32/i64]
    B2[f32/f64]
    B3[内存指针+长度]
    B4[内存指针+长度]
    B5[内存指针+长度]
    end
    
    A1 <--> B1
    A2 <--> B2
    A3 <--> B3
    A4 <--> B4
    A5 <--> B5
    
    C[序列化/反序列化] --- D[内存管理]
    D --- E[指针传递]
```

## 6. Wasmer 集成流程

```mermaid
flowchart TB
    A[开始Wasmer集成] --> B[导入wasmer-go库]
    B --> C[创建WasmInstance结构]
    C --> D[实现NewWasmInstance方法]
    
    D --> E{编译WebAssembly}
    E -->|失败| F[返回编译错误]
    E -->|成功| G[配置WASI环境]
    
    G --> H[注册VM主机函数]
    H --> I[生成WASI导入对象]
    I --> J[实例化WebAssembly模块]
    
    J -->|失败| K[返回实例化错误]
    J -->|成功| L[获取内存和导出函数]
    L --> M[返回WasmInstance]
    M --> N[结束集成]
    
    subgraph 类型转换系统
    O[Go基本类型] --> P[WebAssembly数值类型]
    Q[Go字符串] --> R[内存指针+长度]
    S[Go结构体] --> T[序列化到内存]
    end
    
    subgraph 内存管理系统
    U[AllocateMemory] --> V[调用模块的vm_alloc]
    W[FreeMemory] --> X[调用模块的vm_free]
    Y[ReadMemory] --> Z[读取Memory.Data]
    AA[WriteMemory] --> AB[写入Memory.Data]
    end
    
    subgraph 函数调用流程
    AC[Call方法] --> AD[查找函数缓存]
    AD -->|未找到| AE[从exports获取函数]
    AD -->|已找到| AF[准备WebAssembly参数]
    AE --> AF
    AF --> AG[调用WebAssembly函数]
    AG --> AH[转换返回值到Go类型]
    end
```

这些流程图展示了WASI合约从开发到部署再到执行的完整生命周期，可帮助开发人员理解整个系统的工作原理和各组件之间的交互关系。 
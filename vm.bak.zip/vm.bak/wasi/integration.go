// Package wasi provides WASI integration for the VM
package wasi

import (
	"bytes"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/govm-net/vm/core"
)

// VMIntegration 提供与主虚拟机的集成点
type VMIntegration struct {
	// WASI 执行引擎
	wasiEngine *WASIEngine
	// 上下文适配器，用于将 core.Context 转换为 WASIContext
	contextAdapter *ContextAdapter
}

// NewVMIntegration 创建一个新的虚拟机集成实例
func NewVMIntegration(baseCtx core.Context, wasiDir, tinyGoPath string) (*VMIntegration, error) {
	// 确保目录存在
	if err := os.MkdirAll(wasiDir, 0755); err != nil {
		return nil, fmt.Errorf("failed to create WASI directory: %w", err)
	}

	// 创建 WASI 引擎
	engine, err := NewWASIEngine(wasiDir, tinyGoPath)
	if err != nil {
		return nil, fmt.Errorf("failed to create WASI engine: %w", err)
	}

	// 加载现有合约
	if err := engine.LoadContracts(); err != nil {
		return nil, fmt.Errorf("failed to load existing WASI contracts: %w", err)
	}

	// 创建上下文适配器
	contextAdapter := NewContextAdapter(baseCtx)

	return &VMIntegration{
		wasiEngine:     engine,
		contextAdapter: contextAdapter,
	}, nil
}

// IsWASICode 判断给定的代码是否应该作为 WASI 合约执行
func (vmi *VMIntegration) IsWASICode(code []byte) bool {
	// 检查是否包含 Go 包声明
	if !bytes.Contains(code, []byte("package ")) {
		return false
	}

	// 检查是否包含导出函数（以大写字母开头的函数）
	hasExportedFunc := bytes.Contains(code, []byte("func ")) &&
		bytes.ContainsAny(code, "ABCDEFGHIJKLMNOPQRSTUVWXYZ")

	return hasExportedFunc
}

// HandleDeployRequest 处理合约部署请求
func (vmi *VMIntegration) HandleDeployRequest(source []byte, sender string) (string, error) {
	// 检查是否是 WASI 合约
	if !vmi.IsWASICode(source) {
		return "", fmt.Errorf("not a WASI contract")
	}

	// 使用 WASI 引擎部署合约
	contractAddr, err := vmi.wasiEngine.DeployContract(source, DeployOptions{
		WASIOptions: DefaultWASIOptions(),
		AsWASI:      true,
	})
	if err != nil {
		return "", fmt.Errorf("failed to deploy WASI contract: %w", err)
	}

	// 记录部署事件
	vmi.contextAdapter.Log("ContractDeployed", fmt.Sprintf("Deployed WASI contract at address: %s", contractAddr))

	// 初始化合约状态 - 记录部署者
	err = vmi.contextAdapter.SetState(contractAddr, "owner", []byte(sender))
	if err != nil {
		return "", fmt.Errorf("failed to initialize contract state: %w", err)
	}

	// 初始化合约时间戳
	timestamp := []byte(fmt.Sprintf("%d", time.Now().Unix()))
	err = vmi.contextAdapter.SetState(contractAddr, "timestamp", timestamp)
	if err != nil {
		return "", fmt.Errorf("failed to set contract timestamp: %w", err)
	}

	// 尝试调用初始化方法（如果存在）
	_, initErr := vmi.wasiEngine.ExecuteContract(vmi.contextAdapter, contractAddr, "Init")
	if initErr != nil {
		// 如果不存在 Init 方法，忽略错误；如果是其他错误，则报告
		if !errors.Is(initErr, &WASIError{Message: "WebAssembly execution not implemented yet (tried to call Init)"}) {
			// 这里仍然返回成功，因为合约已经部署，但记录初始化失败
			vmi.contextAdapter.Log("ContractInitFailed", fmt.Sprintf("Failed to initialize contract %s: %v", contractAddr, initErr))
		}
	}

	return contractAddr, nil
}

// HandleExecuteRequest 处理合约执行请求
func (vmi *VMIntegration) HandleExecuteRequest(contractAddress, functionName string, args []interface{}) (interface{}, error) {
	// 检查合约是否存在
	if !vmi.wasiEngine.IsWASIContract(contractAddress) {
		return nil, fmt.Errorf("contract does not exist or is not a WASI contract")
	}

	// 转换参数类型，以便与 ExecuteContract 方法兼容
	varArgs := make([]interface{}, len(args))
	copy(varArgs, args)

	// 记录执行开始
	startTime := time.Now()

	// 执行合约
	result, err := vmi.wasiEngine.ExecuteContract(vmi.contextAdapter, contractAddress, functionName, varArgs...)

	// 记录执行时间
	executionTime := time.Since(startTime)
	vmi.contextAdapter.Log("ContractExecuted", fmt.Sprintf(
		"Executed contract %s::%s in %v",
		contractAddress, functionName, executionTime,
	))

	if err != nil {
		return nil, fmt.Errorf("contract execution failed: %w", err)
	}

	return result, nil
}

// WASIIntegration provides integration between the main VM engine and WASI execution
type WASIIntegration struct {
	engine *WASIEngine
}

// NewWASIIntegration creates a new WASI integration layer
func NewWASIIntegration(wasiDir, tinyGoPath string) (*WASIIntegration, error) {
	// Ensure directories exist
	contractsDir := filepath.Join(wasiDir, "contracts")

	if err := os.MkdirAll(contractsDir, 0755); err != nil {
		return nil, fmt.Errorf("failed to create WASI contracts directory: %w", err)
	}

	// Create the WASI engine
	engine, err := NewWASIEngine(contractsDir, tinyGoPath)
	if err != nil {
		return nil, fmt.Errorf("failed to create WASI engine: %w", err)
	}

	// Load existing contracts
	if err := engine.LoadContracts(); err != nil {
		return nil, fmt.Errorf("failed to load existing WASI contracts: %w", err)
	}

	return &WASIIntegration{
		engine: engine,
	}, nil
}

// Helper method to convert string to core.Address safely
func stringToAddress(s string) core.Address {
	addr, err := core.AddressFromString(s)
	if err != nil {
		// Fallback to zero address if conversion fails
		return core.ZeroAddress()
	}
	return addr
}

// Helper method to convert core.Address to string safely
func addressToString(addr core.Address) string {
	return addr.String()
}

// Modify DeployContract to handle type conversions
func (w *WASIIntegration) DeployContract(code []byte) (core.Address, error) {
	contractAddr, err := w.engine.DeployContract(code, DeployOptions{
		WASIOptions: DefaultWASIOptions(),
		AsWASI:      true,
	})
	if err != nil {
		return core.ZeroAddress(), err
	}

	// Convert the string address to core.Address
	return stringToAddress(contractAddr), nil
}

// Modify IsWASIContract to handle type conversions
func (w *WASIIntegration) IsWASIContract(contract core.Address) bool {
	// Convert core.Address to string
	return w.engine.IsWASIContract(addressToString(contract))
}

// Modify IsWASICode to use more robust checking
func (w *WASIIntegration) IsWASICode(code []byte) bool {
	// Check if the code is Go source code
	if len(code) > 10 {
		// Check for "package main" which is typically at the start of Go source files
		for i := 0; i < len(code)-12; i++ {
			if string(code[i:i+12]) == "package main" {
				return true
			}
		}

		// Check for exported functions
		hasExportedFunc := bytes.Contains(code, []byte("func ")) &&
			bytes.IndexFunc(code, func(r rune) bool {
				return r >= 'A' && r <= 'Z'
			}) != -1

		// Check for GZIP header which indicates compressed Go source
		if len(code) > 2 && code[0] == 0x1f && code[1] == 0x8b {
			return true
		}

		return hasExportedFunc
	}

	return false
}

// AddressFromHexString converts a hex string to a core.Address
func AddressFromHexString(s string) (core.Address, error) {
	return core.AddressFromString(s)
}

// ExecuteContract executes a function on a WASI contract
func (w *WASIIntegration) ExecuteContract(ctx core.Context, contract core.Address, function string, args ...interface{}) (interface{}, error) {
	// Convert contract address to string
	contractAddr := addressToString(contract)

	// Create a context adapter
	contextAdapter := NewContextAdapter(ctx)

	// Use the existing HandleExecuteRequest method
	return w.engine.ExecuteContract(contextAdapter, contractAddr, function, args...)
}

# WebAssembly 系统接口 (WASI) 合约

此模块实现了基于 WebAssembly 系统接口 (WASI) 的智能合约执行环境，允许开发者使用 Go 语言编写智能合约，并将其编译为 WebAssembly 在虚拟机中执行。

## 主要特性

- **直接使用 Go 语言**：可以直接使用 Go 源代码编写智能合约，无需学习新的语言
- **自动导出**：自动识别并导出所有公共方法（以大写字母开头的函数）
- **类型安全**：保持 Go 的类型安全特性，减少错误
- **状态管理**：内置状态存储和检索功能
- **高性能**：使用 TinyGo 编译为高效的 WebAssembly 代码
- **无缝集成**：与现有的虚拟机引擎无缝集成

## 目录结构

```
vm/wasi/
├── cmd/                  # 命令行工具
├── compiler.go           # Go 合约编译器
├── engine.go             # WASI 执行引擎
├── examples/             # 示例合约
│   └── token.go          # 简单的代币合约示例
├── integration.go        # 与主虚拟机集成
├── module.go             # WebAssembly 模块加载与执行
├── FLOW.md               # 流程图文档
├── INTEGRATION.md        # 高级集成指南
└── README.md             # 本文档
```

## 使用说明

### 安装命令行工具

首先，需要安装 TinyGo 编译器，它是将 Go 代码编译为 WebAssembly 的必要工具：

```bash
# 在 macOS 上安装 TinyGo
brew tap tinygo-org/tools
brew install tinygo

# 在 Linux 上安装 TinyGo
wget https://github.com/tinygo-org/tinygo/releases/download/v0.28.1/tinygo_0.28.1_amd64.deb
sudo dpkg -i tinygo_0.28.1_amd64.deb
```

然后，编译并安装 WASI 命令行工具：

```bash
cd vm/wasi/cmd
go build -o wasi-contract
sudo mv wasi-contract /usr/local/bin/
```

### 编写合约

WASI 合约使用标准的 Go 语言编写。以下是一个简单的代币合约示例：

```go
package token

import (
    "errors"
    "math/big"
)

// TokenContract 表示一个简单的代币合约
type TokenContract struct {
    balances map[string]*big.Int
    name     string
    symbol   string
    decimals uint8
    owner    string
}

// Init 初始化代币合约
func (t *TokenContract) Init(owner string, initialSupply *big.Int) error {
    t.balances = make(map[string]*big.Int)
    t.owner = owner
    
    // 为拥有者铸造初始代币
    t.balances[owner] = initialSupply
    return nil
}

// Transfer 转移代币
func (t *TokenContract) Transfer(from, to string, amount *big.Int) error {
    if t.balances[from].Cmp(amount) < 0 {
        return errors.New("insufficient balance")
    }
    
    t.balances[from].Sub(t.balances[from], amount)
    if _, ok := t.balances[to]; !ok {
        t.balances[to] = big.NewInt(0)
    }
    t.balances[to].Add(t.balances[to], amount)
    
    return nil
}

// BalanceOf 查询余额
func (t *TokenContract) BalanceOf(address string) *big.Int {
    if balance, ok := t.balances[address]; ok {
        return balance
    }
    return big.NewInt(0)
}
```

**注意事项：**
1. 所有需要从外部调用的方法必须以大写字母开头（Go 的公共方法）
2. 合约可以使用有限的标准库包（如 `errors`、`math/big`、`encoding/json` 等）
3. 不允许使用网络、文件系统或其他系统资源的包

### 编译与部署合约

使用命令行工具编译合约：

```bash
# 编译合约
wasi-contract compile --source token.go --output token.wasm

# 部署合约
wasi-contract deploy --wasm token.wasm
```

### 执行合约函数

部署后，可以执行合约中的函数：

```bash
# 执行 Init 方法初始化合约
wasi-contract execute --contract 0x123abc... --function Init --args '["0xMyAddress", "1000000000000000000"]'

# 执行 Transfer 方法
wasi-contract execute --contract 0x123abc... --function Transfer --args '["0xFromAddr", "0xToAddr", "1000000000"]'

# 查询余额
wasi-contract execute --contract 0x123abc... --function BalanceOf --args '["0xMyAddress"]'
```

### 与虚拟机集成

要在主引擎中集成 WASI 合约支持，需要初始化 `VMIntegration` 实例并使用它处理部署和执行请求：

```go
import "github.com/govm-net/vm/wasi"

// 创建 WASI 合约集成
wasiIntegration := wasi.NewVMIntegration(context, "/usr/local/bin/tinygo")

// 处理部署请求
contractAddress, err := wasiIntegration.HandleDeployRequest(source, sender)

// 处理执行请求
result, err := wasiIntegration.HandleExecuteRequest(contractAddress, "Transfer", []interface{}{from, to, amount})
```

## 合约部署和执行流程

```mermaid
flowchart TD
    A[接收Go合约源代码] --> B[验证合约]
    B -->|验证通过| C[编译为WebAssembly]
    C --> D[生成合约地址]
    D --> E[存储合约字节码]
    E --> F[返回合约地址]
    
    G[接收执行请求] --> H[加载合约字节码]
    H --> I[创建WebAssembly实例]
    I --> J[准备函数参数]
    J --> K[执行函数]
    K --> L[处理执行结果]
    L --> M[返回结果]
```

## 依赖项

- **TinyGo**: 用于将 Go 代码编译为 WebAssembly
- **Go 1.17+**: 用于构建和运行系统

## 高级主题

有关高级集成和详细流程图，请参考 `INTEGRATION.md` 和 `FLOW.md` 文档。 